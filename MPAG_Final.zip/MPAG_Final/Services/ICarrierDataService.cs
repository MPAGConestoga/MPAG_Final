﻿using MPAG_Final.SharedModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MPAG_Final.Services
{
    public interface ICarrierDataService
    {
        IEnumerable<Carrier> GetCarriers();
        void Save(IEnumerable<Carrier> carriers);
        
    }
}
